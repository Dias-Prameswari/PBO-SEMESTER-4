/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pjppenjualan;
import java.text.DecimalFormat;
/**
 *
 * @author HP
 */
public class CustomFormat {
    public String customFormat(String pattern, double value){
    DecimalFormat myFormatter = new DecimalFormat(pattern);
    String output = myFormatter.format(value);
    return output;
    
    
    }
}
