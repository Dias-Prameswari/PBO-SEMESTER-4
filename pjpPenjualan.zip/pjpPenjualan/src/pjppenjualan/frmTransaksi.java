/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pjppenjualan;
import java.awt.print.PrinterException;
import java.sql.*;
import java.sql.Date.*;
import java.text.MessageFormat;
import javax.swing.*;
import javax.swing.table.*;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class frmTransaksi extends javax.swing.JFrame {

    Connection Con;
    ResultSet RsBrg;
    ResultSet RsKons;
    Statement stm;
    double total = 0;
    String tanggal,tgll;
    Boolean edit=false;
    public TableCellRenderer kanan = new RataKanan();
    public TableCellRenderer tengah = new RataTengah();
    
    DefaultTableModel tableModel = new DefaultTableModel(
            new Object [][]{},
            new String []{
            "Kode Barang", "Nama Barang", "Harga Barang", "Jumlah", "Total"
            }
    );
    
    public String idBrg, namaBrg, hargaBrg;

    public String getIdBrg(){
    return idBrg;
    }
    
    public String getnamaBrg(){
    return namaBrg;
    }
    
    public String gethargaBrg(){
    return hargaBrg;
    }
    
    
    /**
     * Creates new form frmTransaksi
     */
    public frmTransaksi() {
        initComponents();
        open_db();
        inisialisasi_table();
        aktif(false);
        setTombol(true);
        txtTgl.setEditor(new JSpinner.DateEditor(txtTgl, "yyyy/MM/dd"));
        format_tanggal();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
        dtTgl.setDateFormat(sdf);
    }

    private void aturTabel()
    {
            tblJual.getColumnModel().getColumn(2).setCellRenderer(kanan); 
            tblJual.getColumnModel().getColumn(3).setCellRenderer(kanan); 
            tblJual.getColumnModel().getColumn(4).setCellRenderer(kanan);
    }
    
    private void kosongTabel()
    {   try{
            DefaultTableModel dtm = (DefaultTableModel) tblJual.getModel();
            dtm.setNumRows(0); 
        }catch(Exception e){
        }
    }
    
    private int getStok(String xkode)
    {   int jStok=0;
    
        try{
        stm=Con.createStatement();
        ResultSet rs=stm.executeQuery("select kd_barang,stok from barang where kd_barang='" + xkode + "' limit 1");
        rs.beforeFirst();
        
        while(rs.next())
        { 
            jStok=rs.getInt("stok");
        }
        
        rs.close();
        
        }catch(SQLException e)
        { 
            System.out.println("Error : "+e);
        }
        
        return jStok;
    }
    
    private boolean cekRowData(String cari)
    {   boolean cek=false;
        for(int i = 0; i < tblJual.getRowCount(); i++){//For each row
        for(int j = 0; j < tblJual.getColumnCount(); j++){//For each column in that row
            if(tblJual.getModel().getValueAt(i, j).equals(cari)){//Search the model
                System.out.println(tblJual.getModel().getValueAt(i, j));//Print if found string
                cek=true;
            }
        }//For loop inner
    }//For loop outer
        return  cek;
    }

    private double getTotal()
    {   double xtotal=0;
        for(int i = 0; i < tblJual.getRowCount(); i++){//For each row
        {
            xtotal=xtotal+Double.parseDouble(tblJual.getModel().getValueAt(i, 4).toString());
        }
        }
        return xtotal;
    }

    private void hitung_jual(){
        double x_total, x_harga;
        int x_jumlah;
        x_harga = Double.parseDouble(txtHarga.getText());
        x_jumlah = Integer.parseInt(txtJml.getText());
        x_total = x_harga * x_jumlah;
        String x_tl = Double.toString(x_total);
        txtTot.setText(x_tl);
        total = total + x_total;
        txtTotal.setText(Double.toString(total));
    }
    
    private void open_db(){
    try{
            KoneksiMysql kon = new KoneksiMysql("localhost","root","","penjualan");
            Con = kon.getConnection();
                //System.out.println("Berhasil ");
                }catch (Exception e) {
                    System.out.println("Error : "+e);
                }
    }
    
    
    private void baca_konsumen(){
     try{
     //  cmbKd_Kons.removeAllItems();
   stm=Con.createStatement();
   ResultSet rs=stm.executeQuery("select kd_konsumen,nm_konsumen from konsumen");

    rs.beforeFirst();
    while(rs.next())
    {
      //comboBox.addItem(new TypeEntry(rs.getInt(1),rs.getString(2).trim()));
      // cmbKd_Kons.addItem(new TypeEntry(RsKons.getString(1).trim(),RsKons.getString(2).trim()));
      cmbKd_Kons.addItem(rs.getString(1).trim());
    }
    rs.close();
   }
     catch(SQLException e)
     {
         System.out.println("Error : "+e);
     }
    }
    
    public void inisialisasi_table(){
    tblJual.setModel(tableModel);
    }
    
    private void baca_barang(){
    try{
  //  cmbKd_Brg.removeAllItems();
    stm=Con.createStatement();
    ResultSet rs=stm.executeQuery("select * from barang");
   
    rs.beforeFirst();

    while(rs.next())
    {
      cmbKd_Brg.addItem(rs.getString(1).trim());
    }
    rs.close();
   }
     catch(SQLException e)
     {
         System.out.println("Error : "+e);
     }
    }
    
    private void detail_barang(String x_kode){
    try{
    stm=Con.createStatement();
    ResultSet rs=stm.executeQuery("select * from barang where kd_barang='"+x_kode+"'");

    rs.beforeFirst();

    while(rs.next())
    {
      txtNm_Brg.setText(rs.getString(2).trim());
      txtHarga.setText(Double.toString((Double)rs.getDouble(4)));
    }
    rs.close();
   }
     catch(SQLException e)
     {
         System.out.println("Error : "+e);
     }
    }
    
    private void detail_konsumen(String x_kode){
   try{
    stm=Con.createStatement();
    ResultSet rs=stm.executeQuery("select * from konsumen where kd_konsumen='"+x_kode+"'");

    rs.beforeFirst();

    while(rs.next())
    {
      txtNama.setText(rs.getString(2).trim());
    }
    rs.close();
   }
     catch(SQLException e)
     {
         System.out.println("Error : "+e);
     }
    }
    
    //pengkosongan isian
    private void kosong(){
    txtNoJual.setText("");
    txtNama.setText("");
    txtHarga.setText("");
    txtTotal.setText("");
    txtBayar.setText("");
    txtKembali.setText("");
    
    }
    
    //kosongkan detail jual
    private void kosong_detail(){
    txtNm_Brg.setText("");
    txtHarga.setText("");
    txtJml.setText("");
    txtTot.setText("");
    text.setText("");
    }
    
    //aktif on/off isian
    private void aktif(boolean x){
    cmbKd_Kons.setEnabled(x);
    cmbKd_Brg.setEnabled(x);
    txtTgl.setEnabled(x);
    txtJml.setEditable(x);
    txtBayar.setEditable(x);
    }
    
    private void setTombol(boolean t){
//    btn_tambah.setEnabled(t);
//    btn_hpus_item.setEnabled(!t);//(t)
//    btn_simpan.setEnabled(!t);
//    btn_batal.setEnabled(!t);
//    btn_keluar.setEnabled(t);

    cmdTambah.setEnabled(t);
    cmdSimpan.setEnabled(!t);
    cmdBatal.setEnabled(!t);
    cmdKeluar.setEnabled(t);
    cmdHapusItem.setEnabled(!t);
    }
    
    private void nomor_jual(){
    try{
        stm=Con.createStatement();
        ResultSet rs=stm.executeQuery("select no_jual from jual");
        int brs=0;
        
        while(rs.next())
        {
          brs=rs.getRow();
        }
        if(brs==0)
            txtNoJual.setText("1");
        else
        {
            int nom=brs+1;
            txtNoJual.setText(Integer.toString(nom));
        }
            rs.close();
    }
     catch(SQLException e)
     {
         System.out.println("Error : "+e);
     }
        
    }
    
    private void simpan_ditable(){
    try{
        String tKode=cmbKd_Brg.getSelectedItem().toString();
        String tNama=txtNm_Brg.getText();

        double hrg=Double.parseDouble(txtHarga.getText());
        int jml=Integer.parseInt(txtJml.getText());
        double tot=Double.parseDouble(txtTot.getText());
        tableModel.addRow(new Object[]{tKode,tNama,hrg,jml,tot});
        inisialisasi_table();
        
    }catch(Exception e)
    {
        System.out.println("Error : "+e);
    }
    
    }
    
    private void simpan_transaksi(){
    try{
        String x_nojual=txtNoJual.getText();
        format_tanggal();
        String x_kode=cmbKd_Kons.getSelectedItem().toString();
        String msql="insert into jual values('"+x_nojual+"','"+x_kode+"','"+tanggal+"')";
        stm.executeUpdate(msql);
        
        for(int i=0;i<tblJual.getRowCount();i++)
        {
        String xkd=(String)tblJual.getValueAt(i,0);
        double xhrg=(Double)tblJual.getValueAt(i,2);
        int xjml=(Integer)tblJual.getValueAt(i,3);
        String zsql="insert into djual values('"+x_nojual+"','"+xkd+"',"+xhrg+","+xjml+")";
        stm.executeUpdate(zsql);
        
        //update stok
        String ysql="update barang set stok=stok-"+xjml+" where kd_barang='"+xkd+"'";
        stm.executeUpdate(ysql);
        
        }
    }catch(SQLException e){
        System.out.println("Error : "+e);
    }
    
    }
    
    private void format_tanggal()
    {
    String DATE_FORMAT = "yyyy-MM-dd";
    //String DATE_FORMAT = "dd-MM-yyyy"; //Refer Java DOCS for formats
    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat(DATE_FORMAT);
    Calendar c1 = Calendar.getInstance();
    int year=c1.get(Calendar.YEAR);
    int month=c1.get(Calendar.MONTH)+1;
    int day=c1.get(Calendar.DAY_OF_MONTH);
    //tgl1=sdf.format(txtTgl.getValue());
    tgll=dtTgl.getText();
    tanggal=Integer.toString(year)+"-"+Integer.toString(month)+"-"+Integer.toString(day);
    System.out.println("Tanggal  : " + tgll);
    System.out.println("Tanggal2 : " + tanggal);
    }
    
    private class PrintingTask extends SwingWorker<Object, Object> {
    private final MessageFormat headerFormat;
    private final MessageFormat footerFormat;
    private final boolean interactive;
    private volatile boolean complete = false;
    private volatile String message;
//    private final TextArea teks;
    
    public PrintingTask( MessageFormat header, MessageFormat footer, boolean interactive) {
//    this.teks = teks;
    this.headerFormat = header;
    this.footerFormat = footer;
    this.interactive = interactive;
    }
    @Override
    protected Object doInBackground() {
    try {
        
    complete = text.print(headerFormat, footerFormat, true, null, null, interactive);
    message = "Printing " + (complete ? "complete" : "canceled");
    } catch (PrinterException ex) {
    message = "Sorry, a printer error occurred";
    } catch (SecurityException ex) {
    message = "Sorry, cannot access the printer due to security reasons";
    }
    return null;
    }

    @Override
    protected void done() {
//        JOptionPane.showMessageDialog(null, message);
//        System.out.println(message);
    message(!complete, message);
    }
    }
    
    private MessageFormat createFormat(String source) {
        String text = source;
        if (text != null && text.length() > 0) {
            try {
                return new MessageFormat(text);
            } catch (IllegalArgumentException e) {
                error("Sorry, this format is invalid.");
            }
        }
        return null;
    }
    
    private void message(boolean error, String msg) {
        int type = (error ? JOptionPane.ERROR_MESSAGE : JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(this, msg, "Printing", type);
    }

    private void error(String msg) {
        message(true, msg);
    }
    
    public static void createAndShowGUI() {
        JFrame f = new frmTransaksi();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
    
    
    public void itemTerpilih(){
    frmCariBarang fDB = new frmCariBarang();
    fDB.fAB = this;
    txtId.setText(idBrg);
    txtNm_Brg.setText(namaBrg);
    txtHarga.setText(hargaBrg);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dateChooserDialog1 = new datechooser.beans.DateChooserDialog();
        dateChooserDialog2 = new datechooser.beans.DateChooserDialog();
        txtTotal = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTgl = new javax.swing.JSpinner();
        jScrollPane2 = new javax.swing.JScrollPane();
        text = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        txtBayar = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtKembali = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cmbKd_Brg = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        txtNm_Brg = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtHarga = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtJml = new javax.swing.JTextField();
        txtTot = new javax.swing.JTextField();
        btnPilih = new javax.swing.JButton();
        cmdHapusItem = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        cmdTambah = new javax.swing.JButton();
        cmdSimpan = new javax.swing.JButton();
        cmdBatal = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNoJual = new javax.swing.JTextField();
        cmbKd_Kons = new javax.swing.JComboBox();
        txtNama = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblJual = new javax.swing.JTable();
        cmdCetak = new javax.swing.JButton();
        cmdKeluar = new javax.swing.JButton();
        dtTgl = new datechooser.beans.DateChooserCombo();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtTotal.setEditable(false);
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotal.setEnabled(false);

        jLabel5.setText("Total");

        txtTgl.setModel(new javax.swing.SpinnerDateModel());

        text.setColumns(20);
        text.setRows(5);
        jScrollPane2.setViewportView(text);

        jLabel6.setText("Bayar");

        txtBayar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtBayar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtBayarFocusLost(evt);
            }
        });
        txtBayar.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                txtBayarInputMethodTextChanged(evt);
            }
        });
        txtBayar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBayarActionPerformed(evt);
            }
        });
        txtBayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBayarKeyPressed(evt);
            }
        });

        jLabel7.setText("Kembali");

        txtKembali.setEditable(false);
        txtKembali.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtKembali.setEnabled(false);

        jLabel8.setText("Kode Barang");

        jLabel9.setText("Nama Barang");

        cmbKd_Brg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbKd_BrgMouseClicked(evt);
            }
        });
        cmbKd_Brg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbKd_BrgActionPerformed(evt);
            }
        });

        jLabel10.setText("Harga Satuan");

        txtNm_Brg.setEditable(false);
        txtNm_Brg.setEnabled(false);
        txtNm_Brg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNm_BrgActionPerformed(evt);
            }
        });

        jLabel11.setText("Jumlah");

        txtHarga.setEditable(false);
        txtHarga.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtHarga.setEnabled(false);

        jLabel12.setText("Total");

        txtJml.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtJml.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtJmlActionPerformed(evt);
            }
        });
        txtJml.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtJmlKeyPressed(evt);
            }
        });

        txtTot.setEditable(false);
        txtTot.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTot.setEnabled(false);

        btnPilih.setText("Pilih Barang");
        btnPilih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPilihActionPerformed(evt);
            }
        });

        cmdHapusItem.setText("Hapus Item");
        cmdHapusItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdHapusItemActionPerformed(evt);
            }
        });

        cmdTambah.setText("Tambah");
        cmdTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdTambahActionPerformed(evt);
            }
        });

        cmdSimpan.setText("Simpan");
        cmdSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdSimpanActionPerformed(evt);
            }
        });

        cmdBatal.setText("Batal");
        cmdBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdBatalActionPerformed(evt);
            }
        });

        jLabel1.setText("No Jual");

        jLabel2.setText("Tgl. Jual");

        jLabel3.setText("Kode Konsumen");

        jLabel4.setText("Nama Konsumen");

        txtNoJual.setEditable(false);
        txtNoJual.setEnabled(false);

        cmbKd_Kons.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbKd_KonsMouseClicked(evt);
            }
        });
        cmbKd_Kons.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbKd_KonsActionPerformed(evt);
            }
        });

        txtNama.setEditable(false);
        txtNama.setEnabled(false);
        txtNama.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtNamaMouseClicked(evt);
            }
        });
        txtNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNamaActionPerformed(evt);
            }
        });

        tblJual.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblJual);

        cmdCetak.setText("Cetak");
        cmdCetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdCetakActionPerformed(evt);
            }
        });

        cmdKeluar.setText("Keluar");
        cmdKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdKeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNoJual)
                            .addComponent(txtTgl, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(238, 238, 238)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(dtTgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                                .addComponent(jLabel4)))
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbKd_Kons, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmdHapusItem)
                            .addComponent(cmbKd_Brg, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnPilih, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNm_Brg, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtHarga)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtJml, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(txtTot, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(cmdTambah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmdSimpan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmdBatal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmdCetak)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmdKeluar))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addGap(83, 83, 83)
                                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(83, 83, 83)
                                        .addComponent(txtBayar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7)
                                .addGap(83, 83, 83)
                                .addComponent(txtKembali, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNoJual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbKd_Kons, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(txtTgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel9)
                                .addComponent(jLabel10)
                                .addComponent(jLabel8))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel11)
                                .addComponent(jLabel12)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbKd_Brg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNm_Brg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtHarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtJml, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmdHapusItem)
                            .addComponent(btnPilih)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtBayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtKembali, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmdTambah)
                            .addComponent(cmdSimpan)
                            .addComponent(cmdBatal)
                            .addComponent(cmdCetak)
                            .addComponent(cmdKeluar)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(dtTgl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBayarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtBayarFocusLost
        // TODO add your handling code here:
        double tot=Double.parseDouble(txtTotal.getText());
        double byr=Double.parseDouble(txtBayar.getText());
        double kembali=byr-tot;
        txtKembali.setText(Double.toString(kembali));
    }//GEN-LAST:event_txtBayarFocusLost

    private void txtBayarInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_txtBayarInputMethodTextChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_txtBayarInputMethodTextChanged

    private void txtBayarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBayarActionPerformed
        // TODO add your handling code here:
        try{
            if(Double.parseDouble(txtBayar.getText())< Double.parseDouble(txtTotal.getText()))
            {
                JOptionPane.showMessageDialog(null, "Jumlah Bayar lebih kecil (<) dari Total, Ulangi....!!!!");
                return;
            }
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, e);
            return;
        }
        double tot=Double.parseDouble(txtTotal.getText());
        double byr=Double.parseDouble(txtBayar.getText());
        double kembali=byr-tot;
        txtKembali.setText(Double.toString(kembali));
    }//GEN-LAST:event_txtBayarActionPerformed

    private void txtBayarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBayarKeyPressed
        // TODO add your handling code here:
        if (evt.KEY_PRESSED==13)
        {
            double tot=Double.parseDouble(txtTotal.getText());
            double byr=Double.parseDouble(txtBayar.getText());
            double kembali=byr-tot;
            txtKembali.setText(Double.toString(kembali));
        }
    }//GEN-LAST:event_txtBayarKeyPressed

    private void cmbKd_BrgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbKd_BrgMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbKd_BrgMouseClicked

    private void cmbKd_BrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbKd_BrgActionPerformed
        // TODO add your handling code here:
        detail_barang(cmbKd_Brg.getSelectedItem().toString());
    }//GEN-LAST:event_cmbKd_BrgActionPerformed

    private void txtNm_BrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNm_BrgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNm_BrgActionPerformed

    private void txtJmlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtJmlActionPerformed
        // TODO add your handling code here:
        try{
            if(cekRowData(cmbKd_Brg.getSelectedItem().toString())==true)
            {
                JOptionPane.showMessageDialog(null, "Item sudah ada di keranjang..... "+cmbKd_Brg.getSelectedItem().toString());
                return;
            }
            if(Integer.parseInt(txtJml.getText())==0)
            {
                JOptionPane.showMessageDialog(null, "Jumlah Jual masih kososng /0 ");
            }else{
                if(getStok(cmbKd_Brg.getSelectedItem().toString())<Integer.parseInt(txtJml.getText()))
                {
                    JOptionPane.showMessageDialog(null, "Stok tidak mencukupi...!! "+getStok(cmbKd_Brg.getSelectedItem().toString()));
                }else {
                    hitung_jual();
                    simpan_ditable();
                }
            }
        }catch(NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_txtJmlActionPerformed

    private void txtJmlKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtJmlKeyPressed

    }//GEN-LAST:event_txtJmlKeyPressed

    private void btnPilihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPilihActionPerformed
        // TODO add your handling code here:
        frmCariBarang fDB = new frmCariBarang();
        fDB.fAB = this;
        fDB.setVisible(true);
        fDB.setResizable(false);
    }//GEN-LAST:event_btnPilihActionPerformed

    private void cmdHapusItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdHapusItemActionPerformed
        // TODO add your handling code here:
        int row=tblJual.getSelectedRow();
        ((DefaultTableModel) tblJual.getModel()).removeRow(row);
        txtTotal.setText(Double.toString(getTotal()));
        //   inisialisasi_tabel();
    }//GEN-LAST:event_cmdHapusItemActionPerformed

    private void cmdTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdTambahActionPerformed
        // TODO add your handling code here:
        kosong();
        total=0;
        kosong_detail();
        ComboBoxModel c1=new DefaultComboBoxModel();
        ComboBoxModel c2=new DefaultComboBoxModel();
        cmbKd_Kons.setModel(c1);
        cmbKd_Brg.setModel(c2);
        baca_konsumen();
        baca_barang();
        aktif(true);
        setTombol(false);
        nomor_jual();
        //        kosongTabel();
        aturTabel();
    }//GEN-LAST:event_cmdTambahActionPerformed

    private void cmdSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdSimpanActionPerformed
        // TODO add your handling code here:
        try{
            if(Double.parseDouble(txtBayar.getText())< Double.parseDouble(txtTotal.getText()))
            {
                JOptionPane.showMessageDialog(null, "Jumlah Bayar lebih kecil (<) dari Total, Ulangi....!!!!");
                return;
            }

            simpan_transaksi();
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, e);
            return;
        }
        JOptionPane.showMessageDialog(null, "Data Berhasil disimpan");
        aktif(false);
        setTombol(true);
    }//GEN-LAST:event_cmdSimpanActionPerformed

    private void cmdBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdBatalActionPerformed
        // TODO add your handling code here:
        aktif(false);
        setTombol(true);
    }//GEN-LAST:event_cmdBatalActionPerformed

    private void cmbKd_KonsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbKd_KonsMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbKd_KonsMouseClicked

    private void cmbKd_KonsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbKd_KonsActionPerformed
        // TODO add your handling code here:
        detail_konsumen(cmbKd_Kons.getSelectedItem().toString());
    }//GEN-LAST:event_cmbKd_KonsActionPerformed

    private void txtNamaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtNamaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaMouseClicked

    private void txtNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaActionPerformed

    private void cmdCetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdCetakActionPerformed
        // TODO add your handling code here:
        String ctk="Nota Penjualan\nNo    :"+txtNoJual.getText()+"\nTanggal : "+tanggal;
        ctk=ctk+"\n"+"-------------------------------------------------------------------------------------------------";
        ctk=ctk+"\n"+"Kode\tNama Barang\tHarga\tJml\tTotal";
        ctk=ctk+"\n"+"-------------------------------------------------------------------------------------------------";

        for(int i=0;i<tblJual.getRowCount();i++)
        {
            String xkd=(String)tblJual.getValueAt(i,0);
            String xnama=(String)tblJual.getValueAt(i,1);
            double xhrg=(Double)tblJual.getValueAt(i,2);
            int xjml=(Integer)tblJual.getValueAt(i,3);
            double xtot=(Double)tblJual.getValueAt(i,4);
            ctk=ctk+"\n"+xkd+"\t"+xnama+"\t"+xhrg+"\t"+xjml+"\t"+xtot;
        }
        ctk=ctk+"\n"+"-------------------------------------------------------------------------------------------------";
        text.setText(ctk);
        String headerField="";
        String footerField="";
        MessageFormat header = createFormat(headerField);
        MessageFormat footer = createFormat(footerField);
        boolean interactive = true;//interactiveCheck.isSelected();
        boolean background = true;//backgroundCheck.isSelected();

        PrintingTask task = new PrintingTask(header, footer, interactive);
        if (background) {
            task.execute();
        } else {
            task.run();
        }
    }//GEN-LAST:event_cmdCetakActionPerformed

    private void cmdKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdKeluarActionPerformed
        // TODO add your handling code here:
        //System.exit(0);
        dispose();
    }//GEN-LAST:event_cmdKeluarActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmTransaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPilih;
    private javax.swing.JComboBox cmbKd_Brg;
    private javax.swing.JComboBox cmbKd_Kons;
    private javax.swing.JButton cmdBatal;
    private javax.swing.JButton cmdCetak;
    private javax.swing.JButton cmdHapusItem;
    private javax.swing.JButton cmdKeluar;
    private javax.swing.JButton cmdSimpan;
    private javax.swing.JButton cmdTambah;
    private datechooser.beans.DateChooserDialog dateChooserDialog1;
    private datechooser.beans.DateChooserDialog dateChooserDialog2;
    private datechooser.beans.DateChooserCombo dtTgl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblJual;
    private javax.swing.JTextArea text;
    private javax.swing.JTextField txtBayar;
    private javax.swing.JTextField txtHarga;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtJml;
    private javax.swing.JTextField txtKembali;
    private javax.swing.JTextField txtNama;
    private javax.swing.JTextField txtNm_Brg;
    private javax.swing.JTextField txtNoJual;
    private javax.swing.JSpinner txtTgl;
    private javax.swing.JTextField txtTot;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
