package com.mycompany.wabot;

import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import fi.iki.elonen.NanoHTTPD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class frmwa extends javax.swing.JFrame {

    public static final String ACCOUNT_SID = "ACa3405b5f49f171644523a1fdd209a07f";//tgnti
    public static final String AUTH_TOKEN = "76793288541914a362a29404ca26da3e";//gnti
    public static final String TWILIO_WHATSAPP_NUMBER = "whatsapp:+14155238886";

    private static Connection koneksi;
    private HttpServer httpServer;
    private DefaultTableModel memberTableModel;
    private Object[][] dataTable = null;
    private String[] header = {"ID", "Username", "Nomor HP"};


    
    public frmwa() {
        initComponents();
        open_db();
        memberTableModel = new DefaultTableModel();
        baca_data(); // Panggil metode baca_data setelah inisialisasi komponen
        tambahPesanKeTextarea();
        startHttpServer(); // Panggil metode ini untuk memulai HttpServer
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

    }
    
    public frmwa(String user_login) {
        initComponents();
        open_db();
        memberTableModel = new DefaultTableModel();
        baca_data();
        tambahPesanKeTextarea();
        startHttpServer();
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
    }

    
    
    private void startHttpServer() {
        try {
            httpServer = new HttpServer(this); // Mengirim instance Main ke HttpServer
            httpServer.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            System.out.println("Server started on port 8080");
        } catch (Exception ioe) {
            System.err.println("Couldn't start server:\n" + ioe);
        }
    }

     public void tambahPesanKeTextarea() {
        try {
            String sql = "SELECT sender, message_text FROM messages";
            Statement statement = koneksi.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            txtPesanmasukkeluar.setText("");

            while (resultSet.next()) {
                String sender = resultSet.getString("sender");
                String messageText = resultSet.getString("message_text");
                String logPesan = "Pesan dari " + sender + ": " + messageText;
                txtPesanmasukkeluar.append(logPesan + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat mengambil pesan", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
     
    public static void open_db() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/telegram", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Koneksi database gagal: " + e.getMessage());
        }
    }


    
    private List<String> getMemberNumbers() {
    List<String> numbers = new ArrayList<>();

    try {
        // Gunakan koneksi yang sudah ada
        String sql = "SELECT phone_number FROM member";
        Statement statement = koneksi.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            String number = resultSet.getString("phone_number");
            numbers.add("whatsapp:" + number);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mengambil nomor anggota", "Error", JOptionPane.ERROR_MESSAGE);
    }
    return numbers;
}


    private void clearFields() {
        txtNohp.setText("");
        txtUsername.setText("");


    }

    public void baca_data() {//baca data buat member
    try {

        
        // Gunakan koneksi yang sudah ada
        Statement statement = koneksi.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        String sql = "SELECT * FROM member";
        ResultSet rs = statement.executeQuery(sql);

        // Mengambil metadata kolom
        ResultSetMetaData rsMetaData = rs.getMetaData();
        int columnCount = rsMetaData.getColumnCount();

        // Menyiapkan model tabel
        DefaultTableModel tableModel = new DefaultTableModel();
        tblMember.setModel(tableModel);

        // Menambahkan kolom ke model tabel
        for (int i = 1; i <= columnCount; i++) {
            tableModel.addColumn(rsMetaData.getColumnName(i));
        }

        // Menambahkan baris ke model tabel
        while (rs.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                rowData[i - 1] = rs.getObject(i);
            }
            tableModel.addRow(rowData);
        }

        rs.close();
        statement.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "java.sql.SQLException: " + e.getMessage());
    }
    }

    //baca data buat messages
   private void saveMessageToDatabase(String sender, String receiver, String messageText) {
        try (Connection conn = KoneksiMysql.getKoneksi()) {
            if (conn == null) {
                System.err.println("Database connection is null");
                JOptionPane.showMessageDialog(this, "Database connection failed", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "INSERT INTO messages (sender, receiver, message_text) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, sender);
                pstmt.setString(2, receiver);
                pstmt.setString(3, messageText);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Message inserted successfully into database");
                    tambahPesanKeTextarea();
                } else {
                    System.err.println("Failed to insert message into database, affectedRows: " + affectedRows);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNohp = new javax.swing.JTextField();
        txtUsername = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        btn_daftar = new javax.swing.JToggleButton();
        btn_clean = new javax.swing.JToggleButton();
        btn_hapus = new javax.swing.JToggleButton();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtPesanmasukkeluar = new javax.swing.JTextArea();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtBroadcast = new javax.swing.JTextArea();
        btn_keyword = new javax.swing.JToggleButton();
        btn_history = new javax.swing.JToggleButton();
        btn_keluar = new javax.swing.JToggleButton();
        btn_broadcast = new javax.swing.JToggleButton();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblMember = new javax.swing.JTable();
        btn_refresh = new javax.swing.JToggleButton();
        jMenuBar1 = new javax.swing.JMenuBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel1.setText("Member");

        jLabel2.setText("Nomor HP");

        jLabel3.setText("Username");

        btn_daftar.setText("Daftar");
        btn_daftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_daftarActionPerformed(evt);
            }
        });

        btn_clean.setText("Clean");
        btn_clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cleanActionPerformed(evt);
            }
        });

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel5.setText("Broadcast Pesan");

        txtPesanmasukkeluar.setColumns(20);
        txtPesanmasukkeluar.setRows(5);
        jScrollPane1.setViewportView(txtPesanmasukkeluar);

        jLabel6.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel6.setText("Pesan Keluar & Masuk");

        txtBroadcast.setColumns(20);
        txtBroadcast.setRows(5);
        jScrollPane2.setViewportView(txtBroadcast);

        btn_keyword.setText("Kelola Kata Kunci");
        btn_keyword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keywordActionPerformed(evt);
            }
        });

        btn_history.setText("History");
        btn_history.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_historyActionPerformed(evt);
            }
        });

        btn_keluar.setText("Keluar");
        btn_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keluarActionPerformed(evt);
            }
        });

        btn_broadcast.setText("Broadcast");
        btn_broadcast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_broadcastActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel7.setText("Data Member");

        tblMember.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Username", "Nomor HP"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblMember);

        btn_refresh.setText("Refresh");
        btn_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refreshActionPerformed(evt);
            }
        });
        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel1)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btn_daftar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(btn_clean)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel7)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 325, Short.MAX_VALUE)
                                    .addComponent(jSeparator6)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNohp, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtUsername, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(469, 469, 469)
                                .addComponent(btn_hapus)
                                .addGap(18, 18, 18)
                                .addComponent(btn_refresh))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel6)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btn_keyword)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btn_history)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btn_keluar))
                                .addComponent(jScrollPane1)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 623, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 502, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btn_broadcast, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE))
                                .addComponent(jLabel5)
                                .addComponent(jSeparator4)))
                        .addGap(12, 12, 12)))
                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_hapus)
                            .addComponent(btn_refresh)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNohp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_daftar)
                            .addComponent(btn_clean))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_broadcast, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_keyword)
                    .addComponent(btn_history)
                    .addComponent(btn_keluar))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_keywordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keywordActionPerformed
        // TODO add your handling code here:
        new keyword().setVisible(true);
    }//GEN-LAST:event_btn_keywordActionPerformed

    private void btn_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keluarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btn_keluarActionPerformed

    private void btn_broadcastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_broadcastActionPerformed
   String messageBody = txtBroadcast.getText();

   
    if (messageBody.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Pesan tidak boleh kosong", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

    List<String> memberNumbers = getMemberNumbers();
    String from = "whatsapp:+14155238886"; // Pastikan nomor ini benar dan diotorisasi//tokennya

    boolean success = true;

    for (String to : memberNumbers) {
        try {
            Message message = Message.creator(
                    new PhoneNumber(to),
                    new PhoneNumber(from),
                    messageBody).create();

            System.out.println("Pesan berhasil dikirim ke " + to + ": " + message.getSid());
        
            saveMessageToDatabase(from, to, messageBody);

        } catch (ApiException e) {
            JOptionPane.showMessageDialog(this, "Twilio tidak dapat menemukan channel dengan alamat From yang ditentukan: " + from, "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            success = false;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat mengirim pesan ke " + to, "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            success = false;
        }
    }

    if (success) {
        JOptionPane.showMessageDialog(this, "Broadcast berhasil dikirim ke semua anggota!");
    }
    
    KoneksiMysql.closeKoneksi();
    }//GEN-LAST:event_btn_broadcastActionPerformed

    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_refreshActionPerformed
    memberTableModel.setRowCount(0); // Clear the existing rows

    try {
        String sql = "SELECT * FROM member";
        Statement statement = koneksi.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String phoneNumber = resultSet.getString("phone_number");
            memberTableModel.addRow(new Object[]{id, username, phoneNumber});
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_refreshActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
    int selectedRow = tblMember.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Pilih member yang ingin dihapus.");
        return;
    }

    int memberId = (int) tblMember.getValueAt(selectedRow, 0); // Ambil ID dari tabel

    try {
        String sql = "DELETE FROM member WHERE id = ?";
        PreparedStatement statement = koneksi.prepareStatement(sql);
        statement.setInt(1, memberId);
        statement.executeUpdate();

        JOptionPane.showMessageDialog(null, "Member berhasil dihapus.");
        baca_data(); // Refresh data member setelah penghapusan
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menghapus member.", "Error", JOptionPane.ERROR_MESSAGE);
    }




    }//GEN-LAST:event_btn_hapusActionPerformed

    private void btn_daftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_daftarActionPerformed
    String nomorHp = txtNohp.getText();
    String username = txtUsername.getText();

    if (nomorHp.isEmpty() || username.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Nomor HP dan Username tidak boleh kosong.");
        return;
    }

    try {
        String sql = "INSERT INTO member (username, phone_number) VALUES (?, ?)";
        PreparedStatement statement = koneksi.prepareStatement(sql);
        statement.setString(1, username);
        statement.setString(2, nomorHp);
        statement.executeUpdate();

        JOptionPane.showMessageDialog(null, "Member berhasil ditambahkan.");
        clearFields();
        baca_data(); // Refresh data member setelah penambahan
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menambahkan member.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_btn_daftarActionPerformed

    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_historyActionPerformed
        // TODO add your handling code here:
        new history().setVisible(true);
    }//GEN-LAST:event_btn_historyActionPerformed

    private void btn_cleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cleanActionPerformed
        // TODO add your handling code here:
        clearFields();
    }//GEN-LAST:event_btn_cleanActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmwa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmwa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmwa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmwa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmwa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_broadcast;
    private javax.swing.JToggleButton btn_clean;
    private javax.swing.JToggleButton btn_daftar;
    private javax.swing.JToggleButton btn_hapus;
    private javax.swing.JToggleButton btn_history;
    private javax.swing.JToggleButton btn_keluar;
    private javax.swing.JToggleButton btn_keyword;
    private javax.swing.JToggleButton btn_refresh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTable tblMember;
    private javax.swing.JTextArea txtBroadcast;
    private javax.swing.JTextField txtNohp;
    private javax.swing.JTextArea txtPesanmasukkeluar;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}


//    private final String DB_URL = "jdbc:mysql://localhost:3306/telegram";
//    private final String USER = "root";
//    private final String PASS = "";

//    try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
//         PreparedStatement statement = conn.prepareStatement("INSERT INTO member (Username, phone_number) VALUES (?, ?)"))    
//        {
////        String sql = "INSERT INTO member (username, phone_number) VALUES (?, ?)";
////        PreparedStatement statement = koneksi.prepareStatement(sql);
//        statement.setString(1, username);
//        statement.setString(2, nomorHp);
//        statement.executeUpdate();
//
//        JOptionPane.showMessageDialog(null, "Member berhasil ditambahkan.");
//        clearFields();
//        baca_data(); // Refresh data member setelah penambahan
//    } catch (SQLException e) {
//        e.printStackTrace();
//        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menambahkan member.", "Error", JOptionPane.ERROR_MESSAGE);
//    }

//   String pesan = txtBroadcast.getText();
//   tambahPesanKeTextarea();
//        txtBroadcast.setText("");
//        if (koneksi == null) {
//            System.err.println("Koneksi ke database belum terbuka.");
//            return;
//        }
    
//    public String history;
//
//    public frmwa(String history) {
//        initComponents();
//        open_db();
//    }
        
//     public void tambahPesanKeTextarea() {
//        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
//             Statement stmt = conn.createStatement()) {
//            String sql = "SELECT * FROM message ORDER BY timestamp";
//            ResultSet rs = stmt.executeQuery(sql);
//            StringBuilder pesanBuilder = new StringBuilder();
//
//            while (rs.next()) {
//                String body = rs.getString("body");
//                String receiver = rs.getString("receiver");
//
//                if (receiver.equals("+14155238886")) { // Nomor bot (pengirim)
//                    pesanBuilder.append("Pesan keluar: ").append(body).append("\n");
//                } else { // Nomor lain (penerima)
//                    pesanBuilder.append("Pesan masuk: ").append(body).append("\n");
//                }
//            }
//
//            txtPesanmasukkeluar.setText(pesanBuilder.toString());
//        } catch (SQLException e) {
//            e.printStackTrace();
//            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mengambil pesan.", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }
    
//    public void tambahPesanKeTextarea() {
//        new MessageUpdateTask().execute();
//    }
//
//    private class MessageUpdateTask extends SwingWorker<Void, Void> {
//
//        private StringBuilder pesanBuilder = new StringBuilder();
//
//        @Override
//        protected Void doInBackground() throws Exception {
//            try (Statement stmt = koneksi.createStatement()) {
//                String sql = "SELECT * FROM messages ORDER BY  timestamp";
//                ResultSet rs = stmt.executeQuery(sql);
//
//                while (rs.next()) {
//                    String body = rs.getString(" message_text");
//                    String receiver = rs.getString("receiver");
//
//                    if (receiver.equals("+14155238886")) { // Nomor bot (pengirim)
//                        pesanBuilder.append("Pesan keluar: ").append(body).append("\n");
//                    } else { // Nomor lain (penerima)
//                        pesanBuilder.append("Pesan masuk: ").append(body).append("\n");
//                    }
//                }
//                rs.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//                JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mengambil pesan.", "Error", JOptionPane.ERROR_MESSAGE);
//            }
//            return null;
//        }
//
//        @Override
//        protected void done() {
//            txtPesanmasukkeluar.setText(pesanBuilder.toString());
//        }
//    }
//    

//    public String user_login;
//
//    public frmwa(String user_login) {
//        initComponents();
//        open_db();
//    }