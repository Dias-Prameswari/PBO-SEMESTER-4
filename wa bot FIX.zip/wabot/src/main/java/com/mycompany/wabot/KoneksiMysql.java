package com.mycompany.wabot;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class KoneksiMysql {
    private static Connection koneksi;

    private static final String URL = "jdbc:mysql://localhost:3306/telegram"; // Ganti dengan URL database Anda
    private static final String USER = "root"; // Ganti dengan username database Anda
    private static final String PASSWORD = ""; // Ganti dengan password database Anda

    public static Connection getKoneksi() {
        if (koneksi == null || !isConnectionValid()) {
            synchronized (KoneksiMysql.class) {
                if (koneksi == null || !isConnectionValid()) {
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        koneksi = DriverManager.getConnection(URL, USER, PASSWORD);
                    } catch (ClassNotFoundException | SQLException e) {
                        System.err.println("Koneksi database gagal: " + e.getMessage());
                    }
                }
            }
        }
        return koneksi;
    }

    private static boolean isConnectionValid() {
        try {
            return koneksi != null && !koneksi.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    public static void closeKoneksi() {
        if (koneksi != null) {
            try {
                koneksi.close();
                koneksi = null;
            } catch (SQLException e) {
                System.err.println("Gagal menutup koneksi: " + e.getMessage());
            }
        }
    }

    public static void main(String args[]) {
        try (Connection conn = getKoneksi()) {
            if (conn != null) {
                String sql = "INSERT INTO messages (sender, receiver, message_text) VALUES (?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, "test_sender");
                    pstmt.setString(2, "test_receiver");
                    pstmt.setString(3, "test_message");
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        System.out.println("Insert successful");
                    } else {
                        System.err.println("Insert failed");
                    }
                }
            } else {
                System.err.println("Database connection failed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
