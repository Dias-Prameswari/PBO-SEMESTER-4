package com.mycompany.wabot;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class keyword extends javax.swing.JFrame {

    public keyword() {
        initComponents();

        loadKeywords();
        
    }
    
    private void loadKeywords() {
        DefaultTableModel model = (DefaultTableModel) table_keyword.getModel();
        model.setRowCount(0);

        try (Connection conn = KoneksiMysql.getKoneksi()) {
            String sql = "SELECT * FROM keywords";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String keyword = rs.getString("keyword");
                    String response = rs.getString("response");
                    model.addRow(new Object[]{id, keyword, response});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearFields() {
        txt_keyword.setText("");
        txt_respon.setText("");
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_respon = new javax.swing.JTextArea();
        txt_keyword = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btn_simpan = new javax.swing.JToggleButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        table_keyword = new javax.swing.JTable();
        btn_tambah = new javax.swing.JToggleButton();
        btn_update = new javax.swing.JToggleButton();
        btn_hapus = new javax.swing.JToggleButton();
        btn_keluar = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel4.setText("Respon");

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel1.setText("Keyword");

        txt_respon.setColumns(20);
        txt_respon.setRows(5);
        jScrollPane1.setViewportView(txt_respon);

        jLabel3.setText("Keyword");

        btn_simpan.setText("Simpan");
        btn_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanActionPerformed(evt);
            }
        });

        table_keyword.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Keyword", "Respone"
            }
        ));
        table_keyword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_keywordMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(table_keyword);

        btn_tambah.setText("Tambah");
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });

        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        btn_keluar.setText("Keluar");
        btn_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(362, 362, 362)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btn_simpan)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btn_tambah)
                                    .addGap(18, 18, 18)
                                    .addComponent(btn_update)
                                    .addGap(18, 18, 18)
                                    .addComponent(btn_hapus)
                                    .addGap(18, 18, 18)
                                    .addComponent(btn_keluar))
                                .addComponent(jScrollPane3)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txt_keyword, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txt_keyword, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_simpan)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_tambah)
                    .addComponent(btn_update)
                    .addComponent(btn_hapus)
                    .addComponent(btn_keluar))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanActionPerformed
        // TODO add your handling code here:

        String keyword = txt_keyword.getText();
        String response = txt_respon.getText();

        if (keyword.isEmpty() || response.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Keyword and response cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = KoneksiMysql.getKoneksi()) {
            String sql = "INSERT INTO keywords (keyword, response) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, keyword);
                pstmt.setString(2, response);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Keyword saved successfully");
                loadKeywords();
                clearFields();
            }
        } catch (SQLException e) { 
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }


        
    }//GEN-LAST:event_btn_simpanActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        // TODO add your handling code here:
        clearFields();
        
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        // TODO add your handling code here:

        int selectedRow = table_keyword.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a keyword to update", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int id = (int) table_keyword.getValueAt(selectedRow, 0);
        String keyword = txt_keyword.getText();
        String response = txt_respon.getText();

        if (keyword.isEmpty() || response.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Keyword and response cannot be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = KoneksiMysql.getKoneksi()) {
            String sql = "UPDATE keywords SET keyword = ?, response = ? WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, keyword);
                pstmt.setString(2, response);
                pstmt.setInt(3, id);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Keyword updated successfully");
                loadKeywords();
                clearFields();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btn_updateActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:

         int selectedRow = table_keyword.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a keyword to delete", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int id = (int) table_keyword.getValueAt(selectedRow, 0);

        try (Connection conn = KoneksiMysql.getKoneksi()) {
            String sql = "DELETE FROM keywords WHERE id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Keyword deleted successfully");
                loadKeywords();
                clearFields();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void btn_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keluarActionPerformed
        // TODO add your handling code here:
//        System.exit(0);
        dispose();

    }//GEN-LAST:event_btn_keluarActionPerformed

    private void table_keywordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_keywordMouseClicked
        // TODO add your handling code here:
        int selectedRow = table_keyword.getSelectedRow();
        if (selectedRow != -1) {
            txt_keyword.setText(table_keyword.getValueAt(selectedRow, 1).toString());
            txt_respon.setText(table_keyword.getValueAt(selectedRow, 2).toString());
        }
    }//GEN-LAST:event_table_keywordMouseClicked


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(keyword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(keyword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(keyword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(keyword.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new keyword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_hapus;
    private javax.swing.JButton btn_keluar;
    private javax.swing.JToggleButton btn_simpan;
    private javax.swing.JToggleButton btn_tambah;
    private javax.swing.JToggleButton btn_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable table_keyword;
    private javax.swing.JTextField txt_keyword;
    private javax.swing.JTextArea txt_respon;
    // End of variables declaration//GEN-END:variables
}


//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.sql.Statement;
//import javax.swing.JOptionPane;
//import javax.swing.table.DefaultTableModel;

//    Connection Con;
//    ResultSet Rskey;
//    Statement stm;
//    
//    private static Connection koneksi;
//
//
//    private Object[][] dataTable = null;
//    private String[] header = {"ID","Keyword","Response"};

//        open_db();
//        baca_data();

//    private void open_db() {
//        try {
//            Con = KoneksiMysql.getKoneksi();
//            if (Con != null) {
//                System.out.println("Database connected successfully.");
//            } else {
//                System.err.println("Failed to connect to database.");
//            }
//        } catch (Exception e) {
//            System.err.println("Error: " + e.getMessage());
//        }
//    }
    
//    private void open_db()
//    { try{
//            KoneksiMysql kon = new KoneksiMysql("localhost","root","","telegram");
//            Con = kon.getKoneksi();
//                //System.out.println("Berhasil ");
//                }catch (Exception e) {
//                    System.out.println("Error : "+e);
//                }
//    }
    
//    public static void open_db() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/telegram", "root", "");
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null, "Koneksi database gagal: " + e.getMessage());
//        }
//    }
    
//    private void baca_data()
//    {
//    try{
//    stm = Con.createStatement();
//    Rskey = stm.executeQuery("select * from keywords");
//    
//    ResultSetMetaData meta = Rskey.getMetaData();
//    int col = meta.getColumnCount();
//    int baris = 0;
//    while(Rskey.next()) {
//        baris = Rskey.getRow();
//    }
//    
//    dataTable = new Object[baris][col];
//    int x = 0;
//    Rskey.beforeFirst();
//    while(Rskey.next()) {
//        dataTable[x][0] = Rskey.getString("id");
//        dataTable[x][1] = Rskey.getString("key");//kunci
//        dataTable[x][2] = Rskey.getString("response");//balasan
////        dataTable[x][3] = Rskey.getString("message_text");
////        dataTable[x][4] = Rskey.getTimestamp("timestamp");
////        dataTable[x][5] = Rskey.getDate("date");
////        dataTable[x][6] = Rsmsg.getInt("stok_min");
//        x++;
//    }
//    table_keyword.setModel(new DefaultTableModel(dataTable,header));
//    }
//    catch(SQLException e)
//    {
//    JOptionPane.showMessageDialog(null, e);
//    }
//    }
//    
//    private String selectedID;
//
//    private void setField(){
//        int row = table_keyword.getSelectedRow();
//        selectedID = (String) table_keyword.getValueAt(row, 0);
//        txt_keyword.setText((String) table_keyword.getValueAt(row, 1));
//        txt_respon.setText((String) table_keyword.getValueAt(row, 2));
//    }

//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText();
//
//        // Simpan ke database
//        try {
//            String sql = "INSERT INTO keywords (key, response) VALUES ('" + keyword + "', '" + response + "')";
//            stm.executeUpdate(sql);
//            baca_data(); // Update tabel
//            JOptionPane.showMessageDialog(null, "Data berhasil disimpan.");
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//        }

//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText(); // Mengambil teks dari JTextArea
//
//        // Periksa apakah nilai tidak kosong
//        if (keyword.isEmpty() || response.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "Keyword dan Response tidak boleh kosong.");
//            return;
//        }
//
//        // Simpan ke database
//        try {
//            String sql = "INSERT INTO keywords (`key`, `response`) VALUES ('" + keyword + "', '" + response + "')";
//            stm.executeUpdate(sql);
//            baca_data(); // Update tabel
//            JOptionPane.showMessageDialog(null, "Data berhasil disimpan.");
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//        }

//        aktif(true);
//        setTombol(false);
//        kosong();

//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText(); // Mengambil teks dari JTextArea
//
//        // Tambah ke database
//        try {
//            String sql = "INSERT INTO keywords (key, response) VALUES ('" + keyword + "', '" + response + "')";
//            stm.executeUpdate(sql);
//            baca_data(); // Update tabel
//            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan.");
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//        }
//
//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText(); // Mengambil teks dari JTextArea
//
//        // Periksa apakah nilai tidak kosong
//        if (keyword.isEmpty() || response.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "Keyword dan Response tidak boleh kosong.");
//            return;
//        }
//
//        // Tambah ke database
//        try {
//            String sql = "INSERT INTO keywords (`key`, `response`) VALUES ('" + keyword + "', '" + response + "')";
//            stm.executeUpdate(sql);
//            baca_data(); // Update tabel
//            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan.");
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//        }

//        edit=true;
//        aktif(true);
//        setTombol(false);
//        txt_kd_barang.setEditable(false);
        
//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText(); // Mengambil teks dari JTextArea
//
//        // Update database
//        if (selectedID != null) {
//            try {
//                String sql = "UPDATE keywords SET key='" + keyword + "', response='" + response + "' WHERE id='" + selectedID + "'";
//                stm.executeUpdate(sql);
//                baca_data(); // Update tabel
//                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
//            } catch (SQLException e) {
//                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//            }
//        } else {
//            JOptionPane.showMessageDialog(null, "Pilih baris yang ingin diperbarui terlebih dahulu.");
//        }

//        String keyword = txt_keyword.getText();
//        String response = txt_respon.getText(); // Mengambil teks dari JTextArea
//
//        // Periksa apakah nilai tidak kosong
//        if (keyword.isEmpty() || response.isEmpty()) {
//            JOptionPane.showMessageDialog(null, "Keyword dan Response tidak boleh kosong.");
//            return;
//        }
//
//        // Update database
//        if (selectedID != null) {
//            try {
//                String sql = "UPDATE keywords SET `key`='" + keyword + "', `response`='" + response + "' WHERE id='" + selectedID + "'";
//                stm.executeUpdate(sql);
//                baca_data(); // Update tabel
//                JOptionPane.showMessageDialog(null, "Data berhasil diperbarui.");
//            } catch (SQLException e) {
//                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//            }
//        } else {
//            JOptionPane.showMessageDialog(null, "Pilih baris yang ingin diperbarui terlebih dahulu.");
//        }

//        if (selectedID != null) {
//            try {
//                String sql = "delete from keywords where id='" + selectedID + "'";
//                stm.executeUpdate(sql);
//                baca_data();
//                JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
//            } catch (SQLException e) {
//                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//            }
//        } else {
//            JOptionPane.showMessageDialog(null, "Pilih baris yang ingin dihapus terlebih dahulu.");
//        }
