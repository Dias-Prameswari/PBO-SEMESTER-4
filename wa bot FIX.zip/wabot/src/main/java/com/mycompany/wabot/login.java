package com.mycompany.wabot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;


public class login extends javax.swing.JFrame {

    Connection Con;
    ResultSet RsUser;
    Statement stm;
    String user_name;
    

    public login() {
        initComponents();
        open_db();
    }

    public void setUser(String user_nama)
    {
        this.user_name=user_name;
    }
    
    public String getUser()
    {
        return this.user_name;
    }
    
    private void open_db() {
        try {
            Con = KoneksiMysql.getKoneksi();
            if (Con != null) {
                System.out.println("Database connected successfully.");
            } else {
                System.err.println("Failed to connect to database.");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txt_username = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btn_login = new javax.swing.JToggleButton();
        btn_cancel = new javax.swing.JToggleButton();
        txt_password = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel1.setText("Login User");

        txt_username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_usernameActionPerformed(evt);
            }
        });

        jLabel2.setText("Username");

        jLabel3.setText("Password");

        btn_login.setText("Login");
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });

        btn_cancel.setText("Cancel");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(47, 47, 47))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btn_login)
                                .addGap(40, 40, 40)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_username, javax.swing.GroupLayout.DEFAULT_SIZE, 71, Short.MAX_VALUE)
                            .addComponent(btn_cancel)
                            .addComponent(txt_password))))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_login)
                    .addComponent(btn_cancel))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
        // TODO add your handling code here:

        try {
            String userIdInput = txt_username.getText();
            String passwordInput = new String(txt_password.getPassword());

            stm = Con.createStatement();
            String query = "SELECT * FROM users WHERE user_id = ? AND password = ?";
            PreparedStatement pstmt = Con.prepareStatement(query);
            pstmt.setString(1, userIdInput);
            pstmt.setString(2, passwordInput);

            RsUser = pstmt.executeQuery();
            if (RsUser.next()) {
                JOptionPane.showMessageDialog(null, "User dan Password Cocok, silakan masuk");
                user_name = userIdInput;
                new frmwa(user_name).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(null, "User atau Password tidak cocok");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void txt_usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_usernameActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_cancel;
    private javax.swing.JToggleButton btn_login;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_username;
    // End of variables declaration//GEN-END:variables
}
//    private void open_db()
//    { try{
//            KoneksiMysql kon = new KoneksiMysql("localhost","root","","telegram");
//            Con = kon.getKoneksi();
//                //System.out.println("Berhasil ");
//                }catch (Exception e) {
//                    System.out.println("Error : "+e);
//                }
//    }
    
//    public static void open_db() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            Con = DriverManager.getConnection("jdbc:mysql://localhost:3306/telegram", "root", "");
//             System.out.println("Database connected successfully.");
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null, "Koneksi database gagal: " + e.getMessage());
//        }
//    }

//    private static Connection koneksi;

//import com.mysql.jdbc.Connection;

//        try {
//             String userIdInput = txt_username.getText();
//             String passwordInput = new String(txt_password.getPassword());
//
//             stm = Con.createStatement();
//             // Menggunakan PreparedStatement untuk keamanan dan menghindari SQL injection
//             String query = "SELECT * FROM users WHERE user_id = ? AND password = ?";
//             PreparedStatement pstmt = Con.prepareStatement(query);
//             pstmt.setString(1, userIdInput);
//             pstmt.setString(2, passwordInput);
//
//             RsUser = pstmt.executeQuery();
//             int baris = 0;
//             while (RsUser.next()) {
//                 baris = RsUser.getRow();
//             }
//
//             if (baris == 1) {
//                 int psn = JOptionPane.showConfirmDialog(null, "User dan Password Cocok, silakan masuk", "Pesan", JOptionPane.YES_NO_OPTION);
//                 System.out.println("User dan Password Cocok " + psn);
//                 user_name = userIdInput;
//                 System.out.println("User Name : " + user_name);
//                 dispose();
//                 new frmwa(user_name).setVisible(true);
//             } else {
//                 JOptionPane.showMessageDialog(null, "User atau Password tdk Cocok -> " + userIdInput + " --> " + passwordInput);
//             }
//         } catch (SQLException e) {
//             JOptionPane.showMessageDialog(null, e);
//         }
