/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wabot;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String args[]){
    new login().setVisible(true);
    }
}

//    new frmwa().setVisible(true);
