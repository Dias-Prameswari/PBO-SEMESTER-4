package com.mycompany.wabot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class history extends javax.swing.JFrame {

    public history() {
        initComponents();

        loadHistorys();

  
    }
    
    private void loadHistorys() {
        DefaultTableModel model = (DefaultTableModel) table_history.getModel();
        model.setRowCount(0); // Clear existing data

        try (Connection conn = KoneksiMysql.getKoneksi()) {
            String sql = "SELECT id, sender, receiver, message_text, timestamp, message_type FROM messages";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Object[] row = {
                        rs.getString("id"),
                        rs.getString("sender"),
                        rs.getString("receiver"),
                        rs.getString("message_text"),
                        rs.getString("timestamp"),
                        rs.getString("message_type")
                    };
                    model.addRow(row);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading history: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btn_hapus = new javax.swing.JToggleButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        table_history = new javax.swing.JTable();
        jSeparator5 = new javax.swing.JSeparator();
        btn_keluar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 18)); // NOI18N
        jLabel1.setText("History");

        btn_hapus.setText("Hapus");
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });

        table_history.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Pengirim", "Penerima", "Pesan", "waktu"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(table_history);

        btn_keluar.setText("Keluar");
        btn_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_keluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btn_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSeparator5)
                            .addComponent(btn_hapus, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 609, Short.MAX_VALUE)
                            .addComponent(jLabel1))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_hapus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_keluar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:

        int selectedRow = table_history.getSelectedRow();
        if (selectedRow >= 0) {
            String id = table_history.getValueAt(selectedRow, 0).toString();
            try (Connection conn = KoneksiMysql.getKoneksi()) {
                String sql = "DELETE FROM messages WHERE id = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                    pstmt.setString(1, id);
                    pstmt.executeUpdate();
                }
                DefaultTableModel model = (DefaultTableModel) table_history.getModel();
                model.removeRow(selectedRow);
                JOptionPane.showMessageDialog(this, "Message deleted successfully.");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting message: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a message to delete.");
        }

    }//GEN-LAST:event_btn_hapusActionPerformed

    private void btn_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_keluarActionPerformed
        // TODO add your handling code here:
//        System.exit(0);
        dispose();
    }//GEN-LAST:event_btn_keluarActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(history.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(history.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(history.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(history.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new history().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btn_hapus;
    private javax.swing.JButton btn_keluar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JTable table_history;
    // End of variables declaration//GEN-END:variables
}

//import java.sql.DriverManager;


//    Connection Con;
//    ResultSet Rsmsg;
//    Statement stm;
//
//    private static Connection koneksi;
//
//    private Object[][] dataTable = null;
//    private String[] header = {"ID","Pengirim","Penerima","Pesan","Waktu"};
//    

//        open_db();
//        baca_data();


//        table_history.getSelectionModel().addListSelectionListener(event -> {
//        if (!event.getValueIsAdjusting() && table_history.getSelectedRow() != -1) {
//            setField();
//        }
//    });

   
//    private void open_db() {
//        try {
//            Con = KoneksiMysql.getKoneksi();
//            if (Con != null) {
//                System.out.println("Database connected successfully.");
//            } else {
//                System.err.println("Failed to connect to database.");
//            }
//        } catch (Exception e) {
//            System.err.println("Error: " + e.getMessage());
//        }
//    }
    
//    private void open_db()
//    { try{
//            KoneksiMysql kon = new KoneksiMysql("localhost","root","","telegram");
//            Con = kon.getKoneksi();
//                //System.out.println("Berhasil ");
//                }catch (Exception e) {
//                    System.out.println("Error : "+e);
//                }
//    }
    
//    public static void open_db() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/telegram", "root", "");
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null, "Koneksi database gagal: " + e.getMessage());
//        }
//    }
    
//    private void baca_data()
//    {
//    try{
//    stm = Con.createStatement();
//    Rsmsg = stm.executeQuery("select * from message");
//    
//    ResultSetMetaData meta = Rsmsg.getMetaData();
//    int col = meta.getColumnCount();
//    int baris = 0;
//    while(Rsmsg.next()) {
//        baris = Rsmsg.getRow();
//    }
//    
//    dataTable = new Object[baris][col];
//    int x = 0;
//    Rsmsg.beforeFirst();
//    while(Rsmsg.next()) {
//        dataTable[x][0] = Rsmsg.getString("id");
//        dataTable[x][1] = Rsmsg.getString("sender");//pengirim
//        dataTable[x][2] = Rsmsg.getString("receiver");//penerima
//        dataTable[x][3] = Rsmsg.getString("message_text");//pesan
//        dataTable[x][4] = Rsmsg.getTimestamp("timestamp");
//        dataTable[x][5] = Rsmsg.getDate("date");
////        dataTable[x][6] = Rsmsg.getInt("stok_min");
//        x++;
//    }
//    table_history.setModel(new DefaultTableModel(dataTable,header));
//    }
//    catch(SQLException e)
//    {
//    JOptionPane.showMessageDialog(null, e);
//    }
//    }
//    
//    private String selectedID;
//
//    private void setField(){
//        int row = table_history.getSelectedRow();
//        selectedID = (String) table_history.getValueAt(row, 0); 
//    }

//        if (selectedID != null) {
//            try {
//                String sql = "delete from message where id='" + selectedID + "'";
//                stm.executeUpdate(sql);
//                baca_data();
//                JOptionPane.showMessageDialog(null, "Data berhasil dihapus.");
//            } catch (SQLException e) {
//                JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
//            }
//        } else {
//            JOptionPane.showMessageDialog(null, "Pilih baris yang ingin dihapus terlebih dahulu.");
//        }
