package com.mycompany.wabot;

//import com.sun.tools.javac.Main;
import com.sun.tools.javac.Main;
//import fi.iki.elonen.NanoHTTPD;
//import org.json.JSONObject;
import java.util.HashMap;

import java.util.logging.Level;
import java.util.logging.Logger;

import static com.mycompany.wabot.frmwa.TWILIO_WHATSAPP_NUMBER;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoHTTPD.Method;
import fi.iki.elonen.NanoHTTPD.Response;
import fi.iki.elonen.NanoHTTPD.ResponseException;
import java.io.File;
import java.io.IOException;


public class HttpServer extends NanoHTTPD {
    private KoneksiMysql kon;

    private frmwa mainApp; 

    private static final Logger LOGGER = Logger.getLogger(HttpServer.class.getName());

    
    public HttpServer(frmwa mainApp)  {
        //port yang digunakan ngrok http http://localhost:8080
        super(8080); 
        this.mainApp = mainApp;

    }
    
     @Override
    public Response serve(IHTTPSession session) {

        String uri = session.getUri();
        Method method = session.getMethod();
        Map<String, String> files = new java.util.HashMap<>();

        try {
            session.parseBody(files);
        } catch (IOException | ResponseException e) {
            e.printStackTrace();
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Server error");
        }

        Map<String, String> params = session.getParms();

        if ("/webhook".equals(uri) && Method.POST.equals(method)) {
            String from = params.get("From");
            String body = params.get("Body");

            if (from == null || from.isEmpty() || body == null || body.isEmpty()) {
                System.err.println("Invalid request parameters: From or Body is null/empty");
                return newFixedLengthResponse("Invalid request parameters");
            }

            System.out.println("Received message: From=" + from + ", Body=" + body);

            try {
                saveMessageToDatabase(from, TWILIO_WHATSAPP_NUMBER, body, "incoming"); // Simpan pesan ke database

                // Tambahkan pesan ke textarea di frmBot
                mainApp.tambahPesanKeTextarea();

                String response = getResponseForKeyword(body); // Ambil respon berdasarkan keyword

                if (response != null && !response.isEmpty()) {
                    System.out.println("Sending response: " + response);
                    sendMessage(from, response); // Kirim respon jika ada keyword yang cocok
                    saveMessageToDatabase(TWILIO_WHATSAPP_NUMBER, from, response, "outgoing");
                    mainApp.tambahPesanKeTextarea();
                } else {
                    System.out.println("No matching keyword found for body: " + body);
                }

                return newFixedLengthResponse("Message received!");
            } catch (SQLException e) {
                e.printStackTrace();
                return newFixedLengthResponse("Error: " + e.getMessage());
            } catch (Exception e) {
                e.printStackTrace();
                return newFixedLengthResponse("Unexpected Error: " + e.getMessage());
            }
        }

        return newFixedLengthResponse("Invalid request");
    }


    private void saveMessageToDatabase(String sender, String receiver, String messageText, String messageType) throws SQLException {
        try (Connection conn = KoneksiMysql.getKoneksi()) {
            if (conn == null) {
                throw new SQLException("Database connection is null");
            }

            String sql = "INSERT INTO messages (sender, receiver, message_text, message_type) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, sender);
                pstmt.setString(2, receiver);
                pstmt.setString(3, messageText);
                pstmt.setString(4, messageType);
                int affectedRows = pstmt.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Message inserted successfully into database");
                } else {
                    System.err.println("Failed to insert message into database, affectedRows: " + affectedRows);
                }
            }
        }
    }
    
    private String getResponseForKeyword(String body) throws SQLException {
        String response = null;
        String sql = "SELECT response FROM keywords WHERE keyword LIKE ?";
        try (Connection conn = KoneksiMysql.getKoneksi();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, body);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    response = rs.getString("response");
                    System.out.println("Found response for keyword: " + body);
                } else {
                    System.out.println("No response found for keyword: " + body);
                }
            }
        }
        return response;
    }

    private void sendMessage(String to, String messageBody) {
        try {
            Message.creator(
                new PhoneNumber(to),
                new PhoneNumber(TWILIO_WHATSAPP_NUMBER), // Replace with your Twilio number
                messageBody
            ).create();
            System.out.println("Message sent to " + to);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to send message to " + to);
        }
    }


    private void broadcastMessage(String messageBody) throws SQLException {
        try (Connection conn = KoneksiMysql.getKoneksi()) {
            if (conn == null) {
                throw new SQLException("Database connection is null");
            }

            String sql = "SELECT phone_number FROM member";
            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String phoneNumber = rs.getString("phone_number");
                    Message.creator(
                            new PhoneNumber(phoneNumber),
                            new PhoneNumber(TWILIO_WHATSAPP_NUMBER), // Replace with your Twilio number
                            messageBody
                    ).create();
                }
            }
        }
        System.out.println("Broadcast sent successfully");
    }

    private void addKeyword(String keyword, String responseText) throws SQLException {
        try (Connection conn = KoneksiMysql.getKoneksi()) {
            if (conn == null) {
                throw new SQLException("Database connection is null");
            }

            String sql = "INSERT INTO keywords (keyword, response) VALUES (?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, keyword);
                pstmt.setString(2, responseText);
                pstmt.executeUpdate();
            }
        }
        System.out.println("Keyword added successfully");
    }

    public void clear() {
        try {
            File tempFile = new File("C:\\Windows");//
            if (tempFile.exists()) {
                if (!tempFile.delete()) {
                    System.err.println("Could not delete temporary file: " + tempFile.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        frmwa mainApp = new frmwa(); // Initialize your main application instance
        HttpServer server = new HttpServer(mainApp);
        try {
            server.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            System.out.println("HTTP Server started at port 8080");
        } catch (IOException e) {
            System.err.println("Couldn't start server:\n" + e);
        }
    }
}

//        HttpServer server = new HttpServer(mainApp);

//        int port = 8080; // Default port
//        while (true) {
//            try {
//                frmwa mainApp = new frmwa();
//                HttpServer.getInstance(mainApp, port);
//                break; // Berhasil memulai server, keluar dari loop
//            } catch (IOException ioe) {
//               LOGGER.log(Level.WARNING, "Port " + port + " is already in use. Trying next port.", ioe);
//
////                System.err.println("Port " + port + " is already in use. Trying next port.");
//                port++; // Coba port berikutnya
//            }
//        }

        //    public static HttpServer getInstance(frmwa mainApp, int port) throws IOException {
//        if (instance == null) {
//            instance = new HttpServer(mainApp, port);
//        }
//        return instance;
//    }
//
//    @Override
//    public void stop() {
//        super.stop();
//        kon.closeKoneksi();
//        instance = null;
////        System.out.println("server stop");
//        LOGGER.info("Server stopped");
//    }

//    @Override
//    public Response serve(IHTTPSession session) {
//        String uri = session.getUri();
//        Map<String, String> params = session.getParms();
//        Method method = session.getMethod();
//
//        LOGGER.info("Received request: uri=" + uri + ", method=" + method);
//
//        Map<String, String> headers = session.getHeaders();
//        headers.forEach((key, value) -> LOGGER.info("Header: " + key + " = " + value));
//        params.forEach((key, value) -> LOGGER.info("Parameter: " + key + " = " + value));
//
//        if (Method.GET.equals(method) && "/webhook".equals(uri)) {
//            return newFixedLengthResponse("Webhook endpoint is active. Please use POST to send data.");
//        }
//
//        if (Method.POST.equals(method) && "/webhook".equals(uri)) {
//            try {
//                Map<String, String> files = new HashMap<>();
//                session.parseBody(files);
//                params.putAll(session.getParms());
//
//                params.forEach((key, value) -> LOGGER.info("Parameter: " + key + " = " + value));
//
//                // Verifikasi tanda tangan webhook Twilio (jika diperlukan)
//                if (!validateTwilioSignature(headers, params)) {
//                    return newFixedLengthResponse(Response.Status.UNAUTHORIZED, MIME_PLAINTEXT, "Invalid Twilio signature");
//                }
//
//                // Validasi dan proses permintaan
//                String from = params.get("From");
//                String body = params.get("Body");
//
//                if (from == null || body == null) {
//                    return newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "Missing parameters");
//                }
//
//                try (Connection conn = kon.getKoneksi()) {
//                    if (conn == null) {
//                        return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Database connection failed");
//                    }
//
//                    if (body.startsWith("REGISTER ")) {
//                        String[] parts = body.split(" ");
//                        if (parts.length == 2) {
//                            String username = parts[1];
//                            String sql = "INSERT INTO member (username, phone_number) VALUES (?, ?)";
//                            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                                pstmt.setString(1, username);
//                                pstmt.setString(2, from);
//                                pstmt.executeUpdate();
//                            }
//                            LOGGER.info("Registration successful!");
//                            return newFixedLengthResponse("Registration successful!");
//                        }
//                    }
//
//                    String sql = "INSERT INTO messages (id, sender, receiver, message_text, timestamp) VALUES (?, ?, ?, ?, NOW())";
//
////                    String sql = "INSERT INTO messages (sender, receiver, message_text, created_at) VALUES (?, ?, ?, NOW())";
//                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                        pstmt.setString(1, from);
//                        pstmt.setString(2, "+14155238886"); // Ganti dengan nomor Twilio Anda
//                        pstmt.setString(3, body);
//                        pstmt.executeUpdate();
//                        LOGGER.info("Message saved to database.");
//                    }
//
//                    mainApp.tambahPesanKeTextarea();
//                    LOGGER.info("Text area updated.");
//
//                    return newFixedLengthResponse("Message received!");
//                } catch (SQLException e) {
//                    LOGGER.log(Level.SEVERE, "Database error", e);
//                    return newFixedLengthResponse("Error: " + e.getMessage());
//                }
//            } catch (IOException | ResponseException e) {
//                LOGGER.log(Level.SEVERE, "Error parsing request body", e);
//                return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Error parsing request body");
//            }
//        }
//        return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, MIME_PLAINTEXT, "Method not allowed");
//    }
//
//    private boolean validateTwilioSignature(Map<String, String> headers, Map<String, String> params) {
//        // Implementasikan verifikasi tanda tangan Twilio di sini
//        // Return true jika valid, false jika tidak valid
//        return true;
//    }
//    
//    @Override
//    public Response serve(IHTTPSession session) {
//        String uri = session.getUri();
//        Map<String, String> params = session.getParms();
//        Method method = session.getMethod();
//        
//        System.out.println("received request : uri=" + uri + ", method=" + method);
//
//        Map<String, String> headers = session.getHeaders();
//        for (Map.Entry<String, String> entry : headers.entrySet()) {
//            System.out.println("Header: " + entry.getKey() + " = " + entry.getValue());
//        }
//        for (Map.Entry<String, String> entry : params.entrySet()) {
//            System.out.println("Parameter: " + entry.getKey() + " = " + entry.getValue());
//        }
//        
//        if (Method.GET.equals(method) && "/webhook".equals(uri)) {
//            return newFixedLengthResponse("Webhook endpoint is active. Please use POST to send data.");
//        }
//        
//        if (Method.POST.equals(method)) {
//            try {
//                Map<String, String> files = new HashMap<>();
//                session.parseBody(files);
//                params.putAll(session.getParms());
//                
//                for (Map.Entry<String, String> entry : params.entrySet()) {
//                    System.out.println("parameter : " + entry.getKey() + " = " + entry.getValue());
//                }
//            } catch (IOException | ResponseException e) {
//                e.printStackTrace();
//                return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "error parsing request body");
//            }
//            
//            if ("/webhook".equals(uri)) {
//                String from = params.get("From");
//                String body = params.get("Body");
//                
//                System.out.println("Received webhook: from=" + from + ", body=" + body);
//
//                if (from == null || body == null) {
//                    return newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "missing parameters"); 
//                }
//                
//                try (Connection conn = kon.getKoneksi()) {
//                    if (conn == null) {
//                        return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Database connection failed");
//                    }
//                    
//                    if (body.startsWith("REGISTER ")) {
//                        String[] parts = body.split(" ");
//                        if (parts.length == 2) {
//                            String username = parts[1];
//                            String sql = "INSERT INTO member (username, phone_number) VALUES (?, ?)";
//                            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                                pstmt.setString(1, username);
//                                pstmt.setString(2, from);
//                                pstmt.executeUpdate();
//                            }
//                            System.out.println("Registration successful!");
//                            return newFixedLengthResponse("Registration successful!");
//                        }
//                    }
////                    String sql = "INSERT INTO messages (id, sender, receiver, message_text, timestamp) VALUES (?, ?, ?, ?, NOW())";
////                    INSERT INTO `messages`(`id`, `sender`, `receiver`, `message_text`, `timestamp`)
//                    String sql = "INSERT INTO messages (id, sender, receiver, message_text, timestamp) VALUES (?, ?, ?, ?, NOW())";
//                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                        pstmt.setString(1, from);
//                        pstmt.setString(2, "+14155238886"); // ganti dengan nomor Twilio Anda
//                        pstmt.setString(3, body);
//                        pstmt.executeUpdate();
//                        System.out.println("Message saved to database.");
//                    }
//                    
//                    String logPesan = "Pesan masuk dari " + from + ": " + body;
//                    System.out.println(logPesan);
//                    mainApp.tambahPesanKeTextarea();
//
//                    return newFixedLengthResponse("Message received!");   
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                    return newFixedLengthResponse("Error: " + e.getMessage());
//                }
//            }
//            return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Invalid request");
//        }
//        return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, MIME_PLAINTEXT, "Method not allowed");
//    }

        
//        if ("/webhook".equals(uri) && Method.POST.equals(method)) {
//            String from = params.get("From");
//            String body = params.get("Body");
//
//            KoneksiMysql kon = new KoneksiMysql("localhost", "root", "", "telegram");
//            try (Connection conn = kon.getKoneksi()) {
//                if (body != null && body.startsWith("REGISTER ")) {
//                    String[] parts = body.split(" ");
//                    if (parts.length == 2) {
//                        String username = parts[1];
//                        String sql = "INSERT INTO member (username, phone_number) VALUES (?, ?)";
//                        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                            pstmt.setString(1, username);
//                            pstmt.setString(2, from);
////                            pstmt.setString(3, body);
//
//                            pstmt.executeUpdate();
//                        }
//                        return newFixedLengthResponse("Registration successful!");
//                    }
//                }
//
//                String sql = "INSERT INTO messages (sender, receiver, message_text) VALUES (?, ?, ?)";
//                try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                    pstmt.setString(1, from);
//                    pstmt.setString(2, "+14155238886"); // ganti dengan nomor Twilio Anda
//                    pstmt.setString(3, body);
//                    pstmt.executeUpdate();
//                }
//
//                // Menyiapkan log pesan untuk ditampilkan dan disimpan
//                String logPesan = "Pesan masuk dari " + from + ": " + body;
//                System.out.println(logPesan);
//                mainApp.tambahPesanKeTextarea(); //
//
//                return newFixedLengthResponse("Message received!");
//
//            } catch (SQLException e) {
//                e.printStackTrace();
//                return newFixedLengthResponse("Error: " + e.getMessage());
//            }
//            
//        } else if ("/admin".equals(uri) && Method.POST.equals(method)) {
//            String action = params.get("action");
//            String messageText = params.get("message");
//            String keyword = params.get("keyword");
//            String responseText = params.get("response");
//
//            KoneksiMysql kon = new KoneksiMysql("localhost", "root", "", "telegram");//database
//            try (Connection conn = kon.getKoneksi()) {
//                if ("broadcast".equals(action)) {
//                    String sql = "SELECT phone_number FROM member";
//                    try (PreparedStatement stmt = conn.prepareStatement(sql);
//                         ResultSet rs = stmt.executeQuery()) {
//                        while (rs.next()) {
//                            String phoneNumber = rs.getString("phone_number");
//                            // Kirim pesan broadcast menggunakan Twilio API
//                            com.twilio.rest.api.v2010.account.Message.creator(
//                                    new com.twilio.type.PhoneNumber(phoneNumber),
//                                    new com.twilio.type.PhoneNumber("+14155238886"), // ganti dengan nomor Twilio Anda
//                                    messageText
//                            ).create();
//                        }
//                    }
//                    return newFixedLengthResponse("Broadcast sent successfully");
//
//                } else if ("add_keyword".equals(action)) {
//                    String sql = "INSERT INTO keywords (key, response) VALUES (?, ?)";
//                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
//                        pstmt.setString(1, keyword);
//                        pstmt.setString(2, responseText);
//                        pstmt.executeUpdate();
//                    }
//                    return newFixedLengthResponse("Keyword added successfully");
//                }
//
//            } catch (SQLException e) {
//                e.printStackTrace();
//                return newFixedLengthResponse("Error: " + e.getMessage());
//            }
//        }
//
//        return newFixedLengthResponse("Invalid request");

//        this.kon = new KoneksiMysql();
//        start(SOCKET_READ_TIMEOUT, false);
//        instance = this;
////        System.out.println("server started on port : " + port);
//        LOGGER.info("Server started on port : " + port);
